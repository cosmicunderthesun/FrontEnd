package com.example.caps.data.response

import com.example.caps.data.model.Monument

data class MonumentResponse(
    val data: List<Monument>
)